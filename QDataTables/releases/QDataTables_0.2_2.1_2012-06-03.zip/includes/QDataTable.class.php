<?php
	class QDataTable extends QDataTableBase
	{
	}
?>