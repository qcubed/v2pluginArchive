Two separate plugins are required to make Autocomplete work:
- BGIFrame (http://plugins.jquery.com/project/bgiframe)
- Autocomplete - modified version from http://bassistance.de/jquery-plugins/jquery-plugin-autocomplete/. 
... The only modification is around the line that performs the .ajax call - instead, a POST should be done. 