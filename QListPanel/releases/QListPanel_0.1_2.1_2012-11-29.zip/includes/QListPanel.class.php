<?php

/**
 * QListPanel.class.php contains QListPanel Class
 * @package Controls
 */

/**
 * QListPanel is a control that forms a html-list from it's child controls
 * 
 * @package Controls
 */
class QListPanel extends QListPanelBase {
	///////////////////////////
	// ListPanel Preferences
	///////////////////////////
	// Feel free to specify global display preferences/defaults for all QListPanel controls
	//protected $strCssClass = 'list';
//		protected $strFontNames = QFontFamily::Verdana;
//		protected $strFontSize = '10px';
//		protected $blnFontBold = true;
}

?>