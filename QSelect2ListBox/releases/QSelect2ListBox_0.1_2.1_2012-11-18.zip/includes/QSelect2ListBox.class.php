<?php
	class QSelect2ListBox extends QSelect2ListBoxBase
	{
	}
?>