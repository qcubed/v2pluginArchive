<?php $_CONTROL->lblPromptLabel->Render() ?>
<div style="margin: 5px 0 10px 0">
<?php $_CONTROL->radOptions->Render() ?>
</div>
<?php $_CONTROL->lblBottom->Render() ?>