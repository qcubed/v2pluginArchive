<?php $_CONTROL->lblPromptLabel->Render() ?>
<br />
<?php $_CONTROL->lblBottom->Render() ?>