<?php
/**
 * 
 * @author Cfphxd
 * Taken from http://php.net/manual/en/book.curl.php
 * Author: artem at zabsoft dot co dot in
 * His notes on i=origin:
 * Hey I modified script for php 5. Also I add support server auth. and fixed some little bugs on the script.
 * [EDIT BY danbrown AT php DOT net: Original was written by (unlcuky13 AT gmail DOT com) on 19-APR-09.] 
 *
 */


if(class_exists('QChromePhp') && QApplication::IsBrowser(QBrowserType::Chrome)){
	class QDebugger extends ChromePhp{
		private function __construct(){
			parent::__construct();
		}
	}

}
else if(class_exists('QFirebug') && QApplication::IsBrowser(QBrowserType::Firefox)){
	class QDebugger extends QFirebug{
		private function __construct(){
			parent::__construct();
		}
	}
}
else{
	class QDebugger{
		public function __construct(){
		}
		public static function getInstance()
		{
			if (self::$_instance === null) {
				self::$_instance = new QDebugger();
			}
			return self::$_instance;
		}

		public static function log()
		{
			return "";
		}

		public static function warn()
		{
			return "";
		}

		public static function error()
		{
			return "";
		}

		public static function group()
		{
			return "";
		}

		public static function info()
		{
			return "";
		}

	}
}

?>
 