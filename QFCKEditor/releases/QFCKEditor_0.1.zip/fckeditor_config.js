FCKConfig.SkinPath = FCKConfig.BasePath + 'skins/office2003/' ;

FCKConfig.ToolbarSets["QCubed-Default"] = [
	['TextColor','Bold','Italic','-',
     'OrderedList','UnorderedList','-',
     'Link','Unlink','-',
     'Image', 'Smiley','-',
     'FitWindow']
] ;
