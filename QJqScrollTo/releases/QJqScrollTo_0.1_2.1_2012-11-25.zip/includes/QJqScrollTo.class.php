<?php
	/**
	 * This class can be used to place your custom code here.
	 */
	class QJQScrollToAction extends QJQScrollToActionBase
	{
	}
?>