<?php
	/**
	 * The abstract QJQScrollToActionGen class
	 */
	abstract class QJQScrollToActionGen extends QAction	{
		
	}

?>
